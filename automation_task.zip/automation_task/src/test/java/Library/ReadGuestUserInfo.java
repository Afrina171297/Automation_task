package Library;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadGuestUserInfo {
    private String _firstName;
    private String _lastName;
    private String _company;
    private String _city;
    private String _street;
    private String _phoneNumber;
    private String _fax;
    private String _zipCode;
    private String _email;

    public ReadGuestUserInfo() throws CsvValidationException {
        try {

            String CSV_PATH = System.getProperty("user.dir") + "/src/test/java/Resources/GuestUserBillingInfo.csv";

            CSVReader reader = new CSVReader(new FileReader(CSV_PATH));
            String[] csvCell;
            while ((csvCell = reader.readNext()) != null) {
                 _firstName = csvCell[0];
                 _lastName = csvCell[1];
                 _email = csvCell[2];
                 _company = csvCell[3];
                 _city = csvCell[4];
                 _street = csvCell[5];
                 _zipCode = csvCell[6];
                 _phoneNumber = csvCell[7];
                 _fax = csvCell[8];


            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public String getFirstName()
    {
        return _firstName;
    }
    public String getLastName()
    {
        return _lastName;
    }
    public String getCity()
    {
        return _city;
    }
    public String getCompany()
    {
        return _company;
    }
    public String getZipCode()
    {
        return _zipCode;
    }
    public String getPhoneNumber()
    {
        return _phoneNumber;
    }
    public String getFax()
    {
        return _fax;
    }
    public String getStreet()
    {
        return _street;
    }
    public String getEmail()
    {
        return _email;
    }





}

