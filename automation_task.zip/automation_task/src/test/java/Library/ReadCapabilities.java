package Library;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadCapabilities {
    private Properties _properties;
    private final String _deviceName;
    private final String _udid;
    private final String _appPackage;
    private final String _appActivity;
    private final String _automationName;
    private final String _platformName;
    private final String _app;
    private final String _appiumServerUrl;
    private final String _bundleId;
    private final boolean _noReset;
    private final boolean _isInstallationNeeded;
    private final boolean _isRealDevice;
    private final int _driverTimeout;

    public ReadCapabilities() {
        try {
            _properties = new Properties();
            String filePath = "";

            filePath = System.getProperty("user.dir") + "/src/test/java/Resources/Capabilities_Android";


            FileInputStream inputStream;
            inputStream = new FileInputStream(filePath);
            _properties.load(inputStream);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        _deviceName = _properties.getProperty("deviceName");
        _udid = _properties.getProperty("udid");
        _appPackage = _properties.getProperty("appPackage");
        _appActivity = _properties.getProperty("appActivity");
        _appiumServerUrl = _properties.getProperty("appiumServerUrl");
        _automationName = _properties.getProperty("automationName");
        _platformName = _properties.getProperty("platformName");
        _app = _properties.getProperty("app");
        _bundleId = _properties.getProperty("bundleId");
        if (_properties.getProperty("isInstallationNeeded").equals("no")) {
            _isInstallationNeeded = false;
        } else {
            _isInstallationNeeded = true;
        }
        if (_properties.getProperty("isRealDevice").equals("no")) {
            _isRealDevice = false;
        } else {
            _isRealDevice = true;
        }
        if (_properties.getProperty("noReset").equals("no")) {
            _noReset = false;
        } else {
            _noReset = true;
        }
        _driverTimeout = Integer.parseInt(_properties.getProperty("driverTimeout"));
    }
    public String getDeviceName()
    {
        return _deviceName;
    }
    public String getUdid()
    {
        return _udid;
    }
    public String getAppPackage()
    {
        return _appPackage;
    }
    public String getAppActivity()
    {
        return _appActivity;
    }
    public String getAppiumServerUrl()
    {
        return _appiumServerUrl;
    }
    public String getAutomationName()
    {
        return _automationName;
    }
    public String getPlatformName()
    {
        return _platformName;
    }
    public String getApp()
    {
        return _app;
    }
    public String getBundleId()
    {
        return _bundleId;
    }
    public boolean getNoReset()
    {
        return _noReset;
    }
    public boolean getIsInstallationNeeded()
    {
        return _isInstallationNeeded;
    }
    public boolean getIsRealDevice()
    {
        return _isRealDevice;
    }
    public int getDriverTimeout()
    {
        return _driverTimeout;
    }

}
