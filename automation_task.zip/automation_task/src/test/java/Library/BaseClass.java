package Library;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class BaseClass {
    public static AppiumDriver<MobileElement> driver;

    public void start() {
        DesiredCapabilities capability = new DesiredCapabilities();
        ReadCapabilities _config = new ReadCapabilities();

            capability.setCapability(MobileCapabilityType.PLATFORM_NAME, _config.getPlatformName());
            capability.setCapability(MobileCapabilityType.NO_RESET, _config.getNoReset());
            capability.setCapability(MobileCapabilityType.AUTOMATION_NAME, _config.getAutomationName());

            if (_config.getIsRealDevice()) {
                capability.setCapability(MobileCapabilityType.UDID, _config.getUdid());
            } else {
                capability.setCapability(MobileCapabilityType.DEVICE_NAME, _config.getDeviceName());
            }
            if (_config.getIsInstallationNeeded()) {
                capability.setCapability(MobileCapabilityType.APP, _config.getApp());
            } else {
                capability.setCapability("appPackage", _config.getAppPackage());
                capability.setCapability("appActivity", _config.getAppActivity());
            }


        try {
            driver = new AppiumDriver<>(new URL(_config.getAppiumServerUrl()), capability);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }

    }
    public void stop() {
        driver.quit();
    }

    public static void takeScreenshotTestNG(String testMethodName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            String currentDir = "src/test/java/Resources/FailedScreenshots/";
            FileUtils.cleanDirectory(new File(currentDir));
            FileUtils.copyFile(scrFile, new File(currentDir + testMethodName + ".png"));


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }




}





