package Library;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;

public class Operations {
    private static int getTimeout()
    {
        ReadCapabilities _config = new ReadCapabilities();
        return _config.getDriverTimeout();
    }

    public static String getText(By locator, AppiumDriver<MobileElement> driver)
    {
        WebDriverWait wait = new WebDriverWait(driver, getTimeout());
        String text = wait.until(ExpectedConditions.presenceOfElementLocated(locator)).getText();

        return text;
    }

    public static void tap(By locator, AppiumDriver<MobileElement> driver)
    {
        WebDriverWait wait = new WebDriverWait(driver, getTimeout());
        wait.until(ExpectedConditions.presenceOfElementLocated(locator)).click();

    }

        public static boolean isPresent(By locator, AppiumDriver<MobileElement> driver)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, getTimeout());
                wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
          public static void tapByCoordinates(int x, int y, AppiumDriver<MobileElement> driver)
          {
              TouchAction touchAction=new TouchAction(driver);
              touchAction.tap(point(x, y)).perform();
             // touchAction.press(point(x,y)).waitAction(waitOptions(ofSeconds(1))).release().perform();
             // touchAction.tap(PointOption.point(x,y)).perform();
             // PointerInput finger = new PointerInput(org.openqa.selenium.interactions.PointerInput.Kind.TOUCH, "finger"); org.openqa.selenium.interactions.Sequence clickPosition = new org.openqa.selenium.interactions.Sequence(finger, 1); clickPosition .addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x,y)) .addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg())) .addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg())); driver.perform(Arrays.asList(clickPosition));
          }
          public static void enterText(String text, By locator, AppiumDriver<MobileElement> driver)
          {
              WebDriverWait wait = new WebDriverWait(driver, getTimeout());
              wait.until(ExpectedConditions.presenceOfElementLocated(locator)).sendKeys(text);
          }
          public static boolean isVisible(By locator, AppiumDriver<MobileElement> driver)
          {
              String visibleAttributeValue = "";
              try
              {
                  WebDriverWait wait = new WebDriverWait(driver, getTimeout());
                 // if (System.getProperty("device").equals("Android"))
                  {
                      visibleAttributeValue = wait.until(ExpectedConditions.presenceOfElementLocated(locator)).getAttribute("displayed");
                  }
                 /* else
                  {
                      visibleAttributeValue = wait.until(ExpectedConditions.presenceOfElementLocated(locator)).getAttribute("visible");
                  }*/

              }
              catch (Exception ex)
              {
                  return false;
              }
              if (visibleAttributeValue.equals("true"))
              {
                  return true;
              }
              else {
                  return false;
              }
          }
          public static void clearValue(By locator, AppiumDriver<MobileElement> driver)
          {
              WebDriverWait wait = new WebDriverWait(driver, getTimeout());
              wait.until(ExpectedConditions.presenceOfElementLocated(locator)).clear();
          }
          public static void scrollIntoElement(By locator, AppiumDriver<MobileElement> driver)
          {
             // WebDriverWait wait = new WebDriverWait(driver, getTimeout());
             // wait.until(ExpectedConditions.presenceOfElementLocated(locator));
              ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", locator);
         }
          public static AppiumDriver<MobileElement> horizontalSwipeByPercentage (double startPercentage, double endPercentage, double anchorPercentage, AppiumDriver<MobileElement> driver)
          {
              Dimension size = driver.manage().window().getSize();
              int anchor = (int) (size.height * anchorPercentage);
              int startPoint = (int) (size.width * startPercentage);
              int endPoint = (int) (size.width * endPercentage);
              new TouchAction(driver)
                .press(point(startPoint, anchor))
                .waitAction(waitOptions(ofMillis(500)))
                .moveTo(point(endPoint, anchor))
                .release().perform();
              return driver;
          }
          public static void verticalSwipeByPercentages(double startPercentage, double endPercentage, double anchorPercentage, AppiumDriver<MobileElement> driver)
          {
              Dimension size = driver.manage().window().getSize();
              int anchor = (int) (size.width * anchorPercentage);
              int startPoint = (int) (size.height * startPercentage);
              int endPoint = (int) (size.height * endPercentage);
              new TouchAction(driver)
                .press(point(anchor, startPoint))
                .waitAction(waitOptions(ofMillis(500)))
                .moveTo(point(anchor, endPoint))
                .release().perform();
          }
          public static void switchToWebView(AppiumDriver<MobileElement> driver)
          {
              driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
              Set<String> availableContexts = driver.getContextHandles();
              System.out.println("Total No of Context Found After we reach to WebView = " + availableContexts.size());
              for (String context : availableContexts) {
                  if (context.contains("WEBVIEW"))
                  {
                      System.out.println("Context Name is " + context);
                // 4.3 Call context() method with the id of the context you want to access and change it to WEBVIEW_1
                //(This puts Appium session into a mode where all commands are interpreted as being intended for automating the web view)
                      driver.context(context);
                      driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
                      break;
                  }
              }
          }


}



