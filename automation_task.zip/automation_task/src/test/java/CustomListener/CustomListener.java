package CustomListener;

import Library.BaseClass;
import org.testng.ITestListener;
import org.testng.ITestResult;


public class CustomListener extends BaseClass implements ITestListener{
    public void onTestFailure(ITestResult result) {

        System.out.println("Failled test");
        takeScreenshotTestNG(result.getMethod().getMethodName());


    }
}
