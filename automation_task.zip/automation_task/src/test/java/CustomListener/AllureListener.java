package CustomListener;

import Library.BaseClass;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class AllureListener extends BaseClass implements ITestListener {
    @Override
    public void onTestStart(ITestResult result) {
        ITestListener.super.onTestStart(result);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        screenshotOnFailure();
        saveLogs(result.getMethod().getConstructorOrMethod().getName());


    }

    @Attachment(value = "Screenshot", type = "image/png")
    public byte[] screenshotOnFailure() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }
    @Attachment(value = "Stack trace", type = "text/plain")
    public static String saveLogs(String message){
        return message;
    }

}
