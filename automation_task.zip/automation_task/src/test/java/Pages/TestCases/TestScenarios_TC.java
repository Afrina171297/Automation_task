package Pages.TestCases;
import CustomListener.CustomListener;
import Library.BaseClass;
import com.opencsv.exceptions.CsvValidationException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import Pages.ScreenObjects.*;



@Listeners(CustomListener.class)
public class TestScenarios_TC extends BaseClass {

    @BeforeClass
    public void setupDriver()
    {

        start();
    }
    @Test(priority=1,description = "Customer add products in his shopping cart")
    public void testScenario_1() {
        SplashScreen_SO.tapReadAndAcceptBtn();
        Home_SO.scrollIntoElectronicsCard();
        Home_SO.tapElectronicsCard();
        Electronics_SO.scrollIntoMattressBedroomCard();
        Electronics_SO.tapmattressBedroomCard();
        Mattress_SO.scrollIntoPlusBtn();
        Mattress_SO.tapPlusBtn();
        Mattress_SO.tapAddToCartBtn();

    }
    @Test(priority=2,description = "Customer successfully place order as a guest user")
    public void testScenario_2() throws CsvValidationException {
        Mattress_SO.tapCartBtn();
        ShoppingCart_SO.tapCheckoutBtn();
        ShoppingCart_SO.tapCheckoutAsGuestBtn();
        GuestUserInfo_SO.enterGuestUserInfo();
        GuestUserInfo_SO.tapContinueBtn();
        Shipping_SO.tapNextDayAirBtn();
        Shipping_SO.scrollIntoContinueBtn();
        Shipping_SO.tapContinueBtn();
        Payment_SO.scrollIntoContinueBtn();
        Payment_SO.tapCheckMoneyBtn();
        Payment_SO.tapContinueBtn();
        MoneyOrder_SO.tapNextBtn();
        Confirm_SO.tapConfirmBtn();
        Confirm_SO.orderConfirmationMsgTextMatched();

    }


    @AfterClass
    public void quitDriver()
    {

        stop();
    }


}
