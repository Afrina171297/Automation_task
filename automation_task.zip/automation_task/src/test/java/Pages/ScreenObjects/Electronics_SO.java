package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;

public class Electronics_SO extends BaseClass {
    private static class Locator{
        private static By mattressBedroomCard = MobileBy.xpath("//*[contains(@text, 'Mattress Bedroom')]");

    }
    public static void scrollIntoMattressBedroomCard() {
            int maxQuantityOfSwipes = 3;
            boolean isPresent = false;
            for (int i = 0; i < maxQuantityOfSwipes; i++) {
                if (Operations.isPresent(Locator.mattressBedroomCard,driver)) {
                    isPresent = true;
                    break;
                }
                 Operations.verticalSwipeByPercentages(0.75, 0.3, 0.5, driver);
            }
            if (!isPresent) {
                throw new ElementNotVisibleException("Mattress Bedroom element isn't visible. ");
            }


    }

    public static void tapmattressBedroomCard() {

        Operations.tap(Locator.mattressBedroomCard, driver);
    }



}
