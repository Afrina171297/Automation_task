package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;

import static java.lang.Thread.sleep;

public class Payment_SO extends BaseClass {
    private static class Locator{
        private static By checkMoneyBtn = MobileBy.xpath("//*[contains(@text, 'Check / Money Order')]");
        private static By continueBtn = MobileBy.xpath("//*[contains(@text, 'CONTINUE')]");


    }

    public static void tapCheckMoneyBtn() {

        Operations.tap(Locator.checkMoneyBtn, driver);
    }
    public static void scrollIntoContinueBtn() {
        int maxQuantityOfSwipes = 5;
        boolean isPresent = false;
        for (int i = 0; i < maxQuantityOfSwipes; i++) {
            if (Operations.isPresent(Locator.checkMoneyBtn, driver)) {
                isPresent = true;
                break;
            }
            Operations.verticalSwipeByPercentages(0.8, 0.2, 0.5, driver);
        }
        if (!isPresent) {
            throw new ElementNotVisibleException("continue button element isn't visible. ");
        }
    }

        public static void tapContinueBtn() {

            Operations.tap(Locator.continueBtn, driver);

        }



    }





