package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;

public class ShoppingCart_SO extends BaseClass {
    private static class Locator {
        private static By checkoutBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnCheckOut");
        private static By checkoutAsGuestBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnGuestCheckout");


    }



    public static void tapCheckoutBtn() {

        Operations.tap(Locator.checkoutBtn, driver);
    }
    public static void tapCheckoutAsGuestBtn() {

        Operations.tap(Locator.checkoutAsGuestBtn, driver);
    }




}
