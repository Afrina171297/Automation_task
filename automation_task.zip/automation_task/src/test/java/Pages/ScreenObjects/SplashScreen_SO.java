package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
public class SplashScreen_SO extends BaseClass {
    private static class Locator{
        private static By readAndAcceptBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnAccept");

    }


    public static void tapReadAndAcceptBtn()
    {

        Operations.tap(Locator.readAndAcceptBtn, driver);
    }




}
