package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import Library.ReadCapabilities;
import Library.ReadGuestUserInfo;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Random;


public class GuestUserInfo_SO extends BaseClass {

    private static class Locator {
        private static By firstNameInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etFirstName");
        private static By lastNameInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etLastName");
        private static By emailInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etEmail");
        private static By countryDropdown = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/countrySpinner");

        private static By countryOptions = MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[1]");
        private static By companyInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etCompanyName");
        private static By cityInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etCity");
        private static By streetInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etStreetAddress");
        private static By zipInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etZipCode");
        private static By phoneInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etPhone");
        private static By faxInput = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etFax");
        private static By continueBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnContinue");

    }
    public static void enterGuestUserInfo() throws CsvValidationException {
        ReadGuestUserInfo info = new ReadGuestUserInfo();
        Operations.enterText(info.getFirstName(),Locator.firstNameInput,driver);
        Operations.enterText(info.getLastName(),Locator.lastNameInput,driver);
        Operations.enterText(info.getEmail(),Locator.emailInput,driver);
        Operations.tap(Locator.countryDropdown,driver);
        List<MobileElement> options=driver.findElementsByClassName("android.widget.TextView");//using class name
        System.out.println("Total number of options available in dropdown:"+options.size());
        int randomIndex = new Random().nextInt(options.size());
        // Select the random option
        options.get(randomIndex).click();

        
        Operations.enterText(info.getCompany(),Locator.companyInput,driver);
        Operations.verticalSwipeByPercentages(0.8,0.2,0.5,driver);
        Operations.enterText(info.getCity(),Locator.cityInput,driver);
        Operations.enterText(info.getStreet(),Locator.streetInput,driver);
        Operations.enterText(info.getZipCode(),Locator.zipInput,driver);
        Operations.enterText(info.getPhoneNumber(),Locator.phoneInput,driver);
        Operations.enterText(info.getFax(),Locator.faxInput,driver);

    }
    public static void tapContinueBtn() {

        Operations.tap(Locator.continueBtn, driver);
    }

}
