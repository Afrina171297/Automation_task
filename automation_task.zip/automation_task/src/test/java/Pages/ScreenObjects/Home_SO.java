package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.testng.Assert;

public class Home_SO extends BaseClass {
    private static class Locator{
        private static By electronicsCard = MobileBy.xpath("//*[contains(@text, 'Electronics')]");

    }
    public static void scrollIntoElectronicsCard() {
            int maxQuantityOfSwipes = 3;
            boolean isPresent = false;
            for (int i = 0; i < maxQuantityOfSwipes; i++) {
                if (Operations.isPresent(Locator.electronicsCard,driver)) {
                    isPresent = true;
                    break;
                }
                 Operations.horizontalSwipeByPercentage(0.75, 0.3, 0.5, driver);
            }
            if (!isPresent) {
                throw new ElementNotVisibleException("Electronics element isn't visible. ");
            }


    }

    public static void tapElectronicsCard() {

        Operations.tap(Locator.electronicsCard, driver);
    }



}
