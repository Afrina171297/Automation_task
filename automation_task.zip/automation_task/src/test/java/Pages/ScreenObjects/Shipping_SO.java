package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;

public class Shipping_SO extends BaseClass {
    private static class Locator{
        //private static By nextDayAirBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/etPhone");
        private static By nextDayAirBtn = MobileBy.xpath("//*[contains(@text, 'Next Day Air')]");

        private static By continueBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnContinue");


    }

    public static void tapNextDayAirBtn() {

        Operations.tap(Locator.nextDayAirBtn, driver);
    }
    public static void scrollIntoContinueBtn() {
        Operations.verticalSwipeByPercentages(0.75,0.3,0.5,driver);
    }

        public static void tapContinueBtn() {

            Operations.tap(Locator.continueBtn, driver);
        }



    }





