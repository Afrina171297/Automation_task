package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.testng.Assert;

public class Confirm_SO extends BaseClass {
    private static class Locator{
        private static By confirmBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnContinue");
        private static By orderCorfirmationMsg = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/md_text_message");

    }



    public static void tapConfirmBtn() {

        Operations.tap(Locator.confirmBtn, driver);
    }
    public static void orderConfirmationMsgTextMatched() {
        String expectedText = "Your order has been successfully processed!";
        try {
            String actualText = Operations.getText(Locator.orderCorfirmationMsg, driver);
            System.out.println(actualText);

            Assert.assertTrue(actualText.contains(expectedText));
        } catch (Exception exception) {
            Assert.fail("The test is failed because of some unhandled exception. " + exception.getMessage());
        }

    }




}
