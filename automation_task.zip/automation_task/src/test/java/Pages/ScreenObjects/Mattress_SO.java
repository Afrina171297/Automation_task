package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;


public class Mattress_SO extends BaseClass {
    private static class Locator{
        private static By plusBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnPlus");
        private static By addToCartBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/btnAddToCart");
        private static By cartBtn = MobileBy.id("com.nopstation.nopcommerce.nopstationcart:id/counterIcon");


    }
    public static void scrollIntoPlusBtn() {
            int maxQuantityOfSwipes = 3;
            boolean isPresent = false;
            for (int i = 0; i < maxQuantityOfSwipes; i++) {
                if (Operations.isPresent(Locator.plusBtn,driver)) {
                    isPresent = true;
                    break;
                }
                 Operations.verticalSwipeByPercentages(0.75, 0.4, 0.5, driver);
            }
            if (!isPresent) {
                throw new ElementNotVisibleException("plus button element isn't visible. ");
            }


    }

    public static void tapPlusBtn() {

        Operations.tap(Locator.plusBtn, driver);
    }
    public static void tapAddToCartBtn(){

        Operations.tap(Locator.addToCartBtn, driver);

    }
    public static void tapCartBtn() {

        Operations.tap(Locator.cartBtn, driver);
    }





}
