package Pages.ScreenObjects;

import Library.BaseClass;
import Library.Operations;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;

public class MoneyOrder_SO extends BaseClass {
    private static class Locator{
        private static By nextBtn = MobileBy.className("android.widget.Button");

    }



    public static void tapNextBtn() {

        Operations.tap(Locator.nextBtn, driver);
    }



}
